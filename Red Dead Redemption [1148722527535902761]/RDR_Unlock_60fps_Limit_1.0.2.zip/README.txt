English Version

How to use it:

As always, right click on the game and Open Mod Directory / Open Mod Data Location. Drag the "Unlock 60fps Limit" folder inside that directory.

- On Yuzu while you're playing the game press Control U to Unlock FPS. As alternative you can go to Emulation -> Configure -> Vsync Mode and select Inmediate (VSync OFF). Otherwise the max FPS you will get is 60fps (that means mod is not enabled).

- On Ryujinx: Go to Options -> Settings -> System and untick Enable VSync. I don't know if you can setup an shortcut/keybind to do this as alternative.


DISCLAIMER:

I am not the original author of this mod. This is just a reupload. The original author is illusion0001 (I don't know much about him. I just know he is a PS3-PS4 modder). He came to my Github and made a PR adding this mod.

This mod has been possible thanks to him and u/yahfz (a friend of his who tested the mod instead). 

So I want to make it clear that this is not a theft/leak by me or any of them. 

I don't know if there are other people doing the same mod but there are several ways to get to the same thing so let's not make a drama over this.

On the other hand for the people sharing the mod on YouTube/whatever: Don't be pathetic and stupid by deleting the readme and re-uploading the mod to Mediafire/Google Drive/your Discord server or even worse: adding trimmers with lots of ads. 

The mod can be obtained directly without all this (use the original source) and of course you can share it but always giving credits to the creators.

People who want the mod don't have to be forced to subscribe to your channel, make a thousand clicks to get to the final mod link and have to deal with advertising or join your Discord to get the mod.
