This mod fixes the old "Sky island" outline issue that appears when upscaling. The fix works in an improved way. As a side effect, it fixes a lot of rendering issues, such as shimmering light sources, lighting artifacts, etc.
Here is a summary of the issues fixed, besides the islands outline: https://imgsli.com/MTkwNTA0

Credits go to:
theboy181 for finding the function responsible for causing that issue
ChucksFeedAndSeed for reverse engineering tips and tricks, and other useful info
StevenssND for porting to 1.0.0, 1.1.0 and 1.1.1

Follow my updates here https://www.reddit.com/user/PixelKiri
If kind enough to support my work, here's my ko-fi page https://ko-fi.com/pixelkiri